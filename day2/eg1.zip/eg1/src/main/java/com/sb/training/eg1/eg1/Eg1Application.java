package com.sb.training.eg1.eg1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eg1Application {

	public static void main(String[] args) {
		SpringApplication.run(Eg1Application.class, args);
	}

}
