package com.example.demosamplejpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSampleJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
